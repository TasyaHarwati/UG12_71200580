package com.ug12.projectkassa;

import java.lang.reflect.Array;

public class Kasir {
    private Integer pesanan;
    private Array kasir;
    private String kasir;
}
