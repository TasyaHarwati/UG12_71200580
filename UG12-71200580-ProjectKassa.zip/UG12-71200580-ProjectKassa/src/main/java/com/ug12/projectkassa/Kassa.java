package com.ug12.projectkassa;

public class Kassa {
    private long totalPenjualan;
    private String password;
    private String username;
    private String nama;

    public long getTotalPenjualan() {
        return totalPenjualan;
    }

    public String getPassword() {
        return password;
    }

    public String getUsername() {
        return username;
    }

    public String getNama() {
        return nama;
    }
}
